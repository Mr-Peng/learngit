## How to contribute

1. Fork it
2. Clone your project
3. Create your feature branch (`git checkout -b my-feature`)
4. Commit your changes (`git commit -am 'Add some feature'`)
5. Push to the branch (`git push origin my-feature`)
6. Create new Pull Request

