//
//  YTKXMLRequest.h
//  YTKNetwork
//
//  Created by skyline on 16/8/10.
//  Copyright © 2016年 skyline. All rights reserved.
//

#import "YTKBasicHTTPRequest.h"

@interface YTKXMLRequest : YTKBasicHTTPRequest

@end
