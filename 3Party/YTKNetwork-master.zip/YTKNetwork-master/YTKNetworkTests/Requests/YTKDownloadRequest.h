//
//  YTKDownloadRequest.h
//  YTKNetwork
//
//  Created by skyline on 16/8/12.
//  Copyright © 2016年 skyline. All rights reserved.
//

#import "YTKTimeoutRequest.h"

@interface YTKDownloadRequest : YTKTimeoutRequest

@end
