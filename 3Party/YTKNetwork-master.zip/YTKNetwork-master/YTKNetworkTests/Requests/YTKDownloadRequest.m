//
//  YTKDownloadRequest.m
//  YTKNetwork
//
//  Created by skyline on 16/8/12.
//  Copyright © 2016年 skyline. All rights reserved.
//

#import "YTKDownloadRequest.h"

@implementation YTKDownloadRequest

- (YTKResponseSerializerType)responseSerializerType {
    return YTKResponseSerializerTypeHTTP;
}

@end
